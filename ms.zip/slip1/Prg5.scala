class Employee(var empno:Int, var ename:String,var dept:String)
{
	def display()
	{
println("------------------------------------------------------------------------------");
		println("Empno:"+empno);		
		println("Name:"+ename);
		println("Department Name:"+dept)
	}
}
object Prg5
{
	def main(args:Array[String])
	{	
		val e1=new Employee(1,"Ajinkya","finance");
		val e2=new Employee(2,"Sahil","finance");
		val e3= new Employee(3,"Rushikesh","Marketing");
		val e4 =new Employee(4,"Subodh","Marketing");
		var e5=new Employee(5,"Siddhant","Marketing");
		var m1:Map[Int,Employee]=Map(1->e1,2->e2,3->e3,4->e4,5->e5);
		for((k,v)<-m1)
		{
			if(v.dept.equalsIgnoreCase("Finance"))
				v.display()
		}	
		
	}
}

