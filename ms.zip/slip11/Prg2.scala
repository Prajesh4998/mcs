object Prg2
{
	def main(args:Array[String])
	{
		
		println("Enter String:");
		var str1=Console.readLine();
	
		println("Enter String:");
		var str2=Console.readLine();
			
		val result=str1.filter(_!='i');
		println(result);		
	}
}
	
