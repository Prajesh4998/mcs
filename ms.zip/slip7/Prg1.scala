object Prg1
{
	def main(args:Array[String])
	{
		val arr1=Array.ofDim[Int](2,2);//1st array
		val arr2=Array.ofDim[Int](2,2);//2nd array
		var 	rarry=Array.ofDim[Int](2,2)//resultant Array	
                  var isupper=1;	

		println("Enter Matrix1");
		for(i<-0 to 1)
		{
			for(j<-0 to 1)
			{
				arr1(i)(j)=Console.readInt();//read Array1 element
			}
		}
		println("Enter Matrix2");
		for(i<-0 to 1)
		{
			for(j<-0 to 1)
			{
				arr2(i)(j)=Console.readInt();//read Array2 element
			}
		}
		println("MATRIX -1");
	
		for(i<-0 to 1)
		{
			for(j<-0 to 1)
			{
				print(arr1(i)(j)+" ");//print Array Element
			}	
			println();
		}
		println("MATRIX -2");
	
		for(i<-0 to 1)
		{
			for(j<-0 to 1)
			{
				print(arr2(i)(j)+" ");//print Array Element
			}	
			println();
		}
		for(i<-0 to 1)
		{
			for(j<-0 to 1)
			{
				rarry(i)(j)=0;
				for(k<-0 to 1)
						rarry(i)(j)=rarry(i)(j)+arr1(i)(k)*arr2(k)(j);//multiplication
			}
		}
		println("RESULTANT MATRIX");
		
		for(i<-0 to 1)
		{
			for(j<-0 to 1)
			{
				print(rarry(i)(j)+" ");//print Array Element
			}	
			println();
		}
for(i<-0 to 2)
		{
			for(j<-0 to 2)
			{
				if((i>j)&&(rarry(i)(j)!=0))
					 isupper=0;
			}
		}
		if(isupper==1)
			println("Matrix is upper triangular");
		else
			println("Matrix is not upper triangular")
		


		}}

