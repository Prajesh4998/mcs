object Prg18
{
	def main(args:Array[String])
	{
		val str:Array[String]=Array("Hello Good Morning","Hello Good Night","Hello Good Afternoon");
		var str1=" ";
		
		println("Enter string:");
		str1=Console.readLine();
		for(j<-str)
		{
			if(j.indexOf(str1)>=0)
				println(j);
		}
		
	}
}

